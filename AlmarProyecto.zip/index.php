<?php 
    require 'index.vista.php';
?>