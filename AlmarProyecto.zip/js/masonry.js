$('.grid').masonry({
  // options
  itemSelector: '.grid-item',
  columnWidth: 320
});

// $(document).ready(function(){
//   $('.grid').masonry({
//     // options
//     itemSelector: '.grid-item',
//     columnWidth: 200
//   });
// });
